# Nalu AI runtime

Browser GPU/CPU inference, specialist routing, model contracts, response validation, optional Ollama transport, and isolated agent memory. Import individual entries to avoid loading inference workers on the landing page.

The consuming app supplies dedicated Worker factories through `configureLocalAIWorkers`. Model files are public downloads; user prompts are passed to local workers.
