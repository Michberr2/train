# Nalu AI runtime

Browser GPU/CPU inference, specialist routing, model contracts, response validation, optional Ollama transport, and isolated agent memory. Import individual entries to avoid loading inference workers on the landing page.

The consuming app supplies dedicated Worker factories through `configureLocalAIWorkers`. Model files are public downloads; user prompts are passed to local workers.

The coding assignment uses Qwen2.5-Coder-1.5B-Instruct, whose upstream weights are released under Apache-2.0. The 3B research-license variant is not a runtime default. CPU model URLs identify immutable public revisions; quantized artifacts remain subject to their upstream model terms. See the [coding model license](https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct/blob/2e1fd397ee46e1388853d2af2c993145b0f1098a/LICENSE).
